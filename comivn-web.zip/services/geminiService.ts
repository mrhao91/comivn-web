
// Tính năng AI đã được tắt để tránh lỗi build
export const summarizeComic = async (title: string, description: string): Promise<string> => {
  return description;
};
